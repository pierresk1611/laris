import { Dropbox } from 'dropbox';
import fetch from 'node-fetch'; // Agent needs node-fetch if not on Node 18+ native fetch

export async function getRefreshToken() {
    const clientId = process.env.DROPBOX_APP_KEY;
    const clientSecret = process.env.DROPBOX_APP_SECRET;
    const refreshToken = process.env.DROPBOX_REFRESH_TOKEN;

    if (!clientId || !clientSecret || !refreshToken) {
        throw new Error("Missing Dropbox Credentials in .env");
    }

    try {
        const response = await fetch('https://api.dropbox.com/oauth2/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
                'Authorization': 'Basic ' + Buffer.from(clientId + ':' + clientSecret).toString('base64')
            },
            body: new URLSearchParams({
                'grant_type': 'refresh_token',
                'refresh_token': refreshToken
            })
        });

        const data = await response.json();

        if (!response.ok) {
            throw new Error(`Dropbox Token Error: ${data.error_description || data.error || response.statusText}`);
        }

        return data.access_token;
    } catch (e: any) {
        console.error("Failed to refresh Dropbox token:", e);
        throw e;
    }
}

export async function getDropboxClient() {
    const accessToken = await getRefreshToken();
    return new Dropbox({ accessToken, fetch: fetch as any });
}
